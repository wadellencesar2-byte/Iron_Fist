# Iron Fist — Multiplayer + Contas + Ranking

Esta pasta vem com os 4 arquivos que você precisa:

```
meu-jogo/
├── index.html   → o jogo (front-end)
├── server.js    → o servidor (rotas de conta + WebSocket do multiplayer)
├── db.js        → o banco de dados (contas, senhas, progresso, ranking)
└── package.json → dependências do servidor
```

Siga os passos abaixo NA ORDEM.

---

## 1. Testar localmente (recomendado antes de publicar)

Precisa ter o [Node.js](https://nodejs.org) instalado.

```bash
cd meu-jogo
npm install
npm start
```

Abra `http://localhost:3000`. Crie uma conta, jogue um pouco, feche e abra nas mesmas credenciais
pra confirmar que salvou. Abra em duas abas pra testar o multiplayer (duas contas diferentes).

> Local, deixe `WS_URL` como está (`ws://localhost:3000`) — só troca depois de publicar (passo 4).

---

## 2. Criar o repositório no GitHub

```bash
cd meu-jogo
git init
git add index.html server.js db.js package.json
git commit -m "jogo com contas, ranking e multiplayer"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/iron-fist-multiplayer.git
git push -u origin main
```

(Ou suba os 4 arquivos direto pela página do GitHub, sem usar terminal, se preferir.)

---

## 3. Publicar no Render

1. [render.com](https://render.com) → login → **New** → **Web Service**.
2. Escolha o repositório.
3. **Runtime**: `Node` · **Build Command**: `npm install` · **Start Command**: `npm start`.
4. **Create Web Service**.

Depois de alguns minutos você recebe uma URL, tipo:
```
https://iron-fist-servidor.onrender.com
```
**Guarde essa URL.**

> ⚠️ Plano free do Render "dorme" sem uso e demora ~30-60s pra acordar no primeiro acesso. Normal do plano grátis.

---

## 4. Conectar o jogo ao servidor

No `index.html`, ache (Ctrl+F) a linha:
```js
const WS_URL = 'wss://TROQUE-PELA-URL-DO-SEU-SERVIDOR.onrender.com';
```
Troque pela sua URL do Render, com `wss://` (não `https://`):
```js
const WS_URL = 'wss://iron-fist-servidor.onrender.com';
```
Salve, suba pro GitHub de novo (`git add . && git commit -m "conecta servidor" && git push`) —
o Render republica sozinho.

---

## 5. Contas e banco de dados — como funciona

- Ao digitar nome + senha na tela de login, o jogo tenta entrar num banco de dados de verdade
  no servidor (arquivo `database.sqlite`, gerenciado pelo `db.js`).
- **Se o nome não existe ainda**, cria a conta automaticamente.
- **Nomes repetidos são proibidos** — o banco não deixa criar duas contas com o mesmo nome
  (sem diferenciar maiúscula/minúscula: "Cesar" e "cesar" contam como o mesmo).
- Senhas ficam guardadas com **hash** (bcrypt), nunca em texto puro.
- Se o servidor estiver offline/não configurado ainda, o jogo cai automaticamente pro modo local
  (salva só no navegador, como antes) — assim nunca trava o jogo de ninguém.

> ⚠️ **Sobre persistência no Render**: no plano **gratuito**, o disco onde o `database.sqlite`
> mora é temporário — um novo deploy ou reinício do serviço apaga os dados. Pra testar e usar no
> dia a dia funciona liso. Se quiser que as contas **nunca** se percam:
> - Ative um **Persistent Disk** no Render (pago, mas resolve na hora, sem mudar nada de código), ou
> - Troque pra um banco externo de verdade (MongoDB Atlas tem plano grátis) — me chama se quiser
>   ajuda com essa migração.

## 6. Ranking

Lobby → **RANKING** (no menu lateral). Mostra os 20 melhores recordes, com avatar e nome de
cada jogador, direto do banco de dados — todo mundo vê o mesmo ranking, de qualquer aparelho.

## 7. Conta Admin

O botão de admin **só aparece** se você logar com usuário `CESAR` e senha `12345` — pra
qualquer outra conta, esse botão simplesmente não existe na tela. Além disso, ele ainda pede
um código extra (o numpad que já existia no jogo) antes de abrir o painel de verdade.

## 8. Como jogar o co-op de Invasão Zumbi

Lobby → **MODOS** → **🧟 INVASÃO ZUMBI ONLINE — CO-OP** → **ENTRAR NO ONLINE**.

- **Criar sala**: gera um código de 5 caracteres pra compartilhar. Quem cria é o **HOST**.
- **Entrar em sala**: digita o código. Até **4 jogadores** por sala.
- Host aperta **COMEÇAR PARTIDA** quando todo mundo estiver dentro.
- Todos veem os **mesmos zumbis, com a mesma vida**, ajudando uns aos outros — sem PvP.
  Mais jogadores na sala = mais zumbis vindo, pra continuar desafiador em grupo.

---

## O que JÁ funciona nesta versão

- **Contas de verdade no banco de dados** (SQLite via `db.js`): criação automática, login,
  nomes únicos (proibido repetir), senha com hash.
- **Progresso salvo no servidor** (moedas, upgrades, personagens, missões, tudo) — some do
  navegador, mas continua na conta, disponível de qualquer aparelho que logar com ela.
- **Ranking real** buscado do banco, visível por todo mundo.
- **Botão admin só pra conta CESAR/12345**, escondido pra qualquer outra conta.
- **Combate multiplayer de verdade, autoritativo**: o HOST decide TUDO — vida de cada zumbi,
  quem cada zumbi ataca (escolhe o alvo mais próximo entre o host e cada convidado, não só o
  host), e quanto de dano cada jogador recebe. Todo mundo recebe a mesma recompensa quando um
  zumbi morre, não importa quem deu o golpe final.
- Salas com código, limite de 4 jogadores, entrada/saída, sincronização de posição em tempo real.

## O que ainda NÃO está pronto (próximos passos)

- **Se o HOST sair ou morrer, a invasão trava pra todo mundo** (é o jogo dele que roda a
  simulação de verdade). "Trocar de host" automático no meio da partida é possível, mas é mais
  trabalho — avisa se quiser que eu faça isso.
- **Persistência do banco no Render free** — veja o aviso da seção 5 acima.
- **Só o modo Invasão Zumbi tem co-op.** O Modo Clássico continua single-player — dá pra levar
  esse mesmo sistema de salas pra ele depois.

Se quiser, a gente continua evoluindo isso aos poucos.
